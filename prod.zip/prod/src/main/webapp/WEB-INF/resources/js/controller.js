/*var app=angular.module("app",[])
.controller("myController",function($scope,$http){

	$scope.getProductList = function(){
		   $http.get('http://localhost:8080/prod/getProductsList').success(function (data){
		       $scope.products = data;
		   });
		};
});
*/
var myapp=angular.module("myapp",[]).controller("productController",function($scope,$http){
	$scope.trial="working?";
	
	$scope.getProducts=function(){
		alert('Refresh List')
		
	$http.get('http://localhost:8080/prod/getAllProducts').success(function(data){
		// $scope.product=data;
			});
		
		$http.get('http://localhost:8080/prod/getProductsList').success(function(data){
			$scope.products=data;
		});
	
	
	}
	
	
	$scope.addToCart=function(productid){
		   $http.put('http://localhost:8080/prod/cart/add/'+productid).success(function(){
			   alert('Added Successfully');
		   })
	   }
	    	
	
    $scope.refreshCart=function(){
    	alert('refreshcart')
    	$http.get('http://localhost:8080/prod/cart/getCart/'+$scope.cartId).success(function(data){
    		$scope.cart=data;
    	})
    } 

    $scope.getCart=function(cartId){
    	$scope.cartId=cartId;
    	$scope.refreshCart(cartId);
    }
   
    $scope.removeFromCart=function(cartItemId){
    	$http.put('http://localhost:8080/prod/cart/removecartitem/'+cartItemId).success(function(){
	$scope.refreshCart();
        })
      }

    	$scope.clearCart=function(){
    	$http.put('http://localhost:8080/prod/cart/removeAllItems/'+/*cartId*/$scope.cartId).success(function(){
	    $scope.refreshCart();
         });
       }

    	$scope.calculateGrandTotal=function(){
    		
    		var grandTotal=0.0;
    		for(var i=0;i<$scope.cart.cartItem.length;i++){
    			grandTotal=grandTotal+$scope.cart.cartItem[i].totalPrice;
    			}
    	
    		return grandTotal;
    		}
    
    
     
});