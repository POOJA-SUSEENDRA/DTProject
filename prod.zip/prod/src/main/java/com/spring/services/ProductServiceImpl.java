package com.spring.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.dao.ProductDao;
import com.spring.model.Product;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
private ProductDao productDao;

	public ProductDao getProductDao() {
		return productDao;
	}

	public void setProductDao(ProductDao productDao) {
		this.productDao = productDao;
	}

	
  @Transactional
	public List<Product> getAllProducts() {
		return productDao.getAllProducts();
	}

  public Product getProductById(int id) {

		return productDao.getProductById(id);
}

  public void deleteProduct(int id) {
		 productDao.deleteProduct(id);
		
	}
  public void addProduct(Product product) {
      productDao.addProduct(product);
     }

public void editProduct(Product product) {
	
	System.out.println("in edit product");
	
	System.out.println("Product Details"+product.getProductid() + " "+product.getProductname()+ " "+product.getProductmanufacturer()+ " "+product.getCategory().getCategoriesid()+" "+ product.getCategory().getCategories() + " "+product.getProductdescription()+ " "+product.getUnitinstock()+ " "+product.getProductprice());
	
	 productDao.editProduct(product);
}

 





}

