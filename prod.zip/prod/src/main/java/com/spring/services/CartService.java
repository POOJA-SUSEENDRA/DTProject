package com.spring.services;

import com.spring.model.Cart;

public interface CartService {
Cart getCartByCartId(int cartId);
}

