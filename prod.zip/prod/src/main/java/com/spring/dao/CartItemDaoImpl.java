package com.spring.dao;

import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.spring.model.Cart;
import com.spring.model.CartItem;
import com.spring.model.Product;
@Repository
@Transactional

public class CartItemDaoImpl implements CartItemDao {
	@Autowired
	private SessionFactory sessionFactory;
/*
	@Autowired
	private CartItem cartItem;
	
	public CartItem getCartItem() {
		return cartItem;
	}

	public void setCartItem(CartItem cartItem) {
		this.cartItem = cartItem;
	}*/
	
	private Product product; 
	
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void addCartItem(CartItem cartItem) {
		Session session=sessionFactory.openSession();
		session.saveOrUpdate(cartItem);
		session.flush();
	    session.close();
		
	}

	public void removeCartItem(int cartItemId) {
		Session session=sessionFactory.openSession();
		CartItem cartItem=(CartItem)session.get(CartItem.class, cartItemId);
		session.delete(cartItem);
		Cart cart=cartItem.getCart();
		List<CartItem> cartItems=cart.getCartItem();
		cartItems.remove(cartItem);
		session.flush();
		session.close();
	}

	public void removeAllCartItems(Cart cart) {
		List<CartItem> cartItems=cart.getCartItem();
		
		System.out.println(cartItems);
		
		/*List<CartItem> cartItem =cartItem.getProduct();*/
		
		/*cartItem.getProduct().getUnitinstock();
		for(int a:cartItemId)
		{
		int i=cartItem.getCartItemId();
		
		}	*/	
		
		/*System.out.println(cartItem.getQuantity());*/
		
		
		/*CartItem cartItem = null ;*/
		
		/*
		int i= cartItem.getQuantity();
		int j=cartItem.getProduct().getUnitinstock();
		int k=j-i;
		cartItem.getProduct().setUnitinstock(k);
		System.out.println(k);
		*/
		
		
		
		for(CartItem cartItem1:cartItems){
			removeCartItem(cartItem1.getCartItemId());
		}
		
	}

	

	public void unitInStock(Cart cart)
	{
		//CartItem cartItem=null;
		//Session session=sessionFactory.openSession();
		/*CartItem cartItem=null;
		int i= cartItem.getQuantity();
		int j=cartItem.getProduct().getUnitinstock();
		int k=j-i;
		//session.update(k);
		cartItem.getProduct().setUnitinstock((cartItem.getProduct().getUnitinstock())-1);
		//System.out.println(k);
		 * 
*/		Session session=sessionFactory.openSession();
		
		List<CartItem> cartItems=cart.getCartItem();
		for(CartItem  c : cartItems)
		{
		
			session.getTransaction().begin();
		
		int i=c.getQuantity();
		/*int j=c.getProduct().getUnitinstock();
		int k=j-i;*/
		
		/*System.out.println("quantity selected"+i);
		System.out.println();
		System.out.println("unit of stocks selected"+j);
		System.out.println("updated value of unit of stocks"+k);
		System.out.println(c.getProduct());
		*/
		Product p=c.getProduct();
		p.setUnitinstock(p.getUnitinstock() - i);
		session.update(p);
		
		session.getTransaction().commit();
		/*((CartItem) cart.getCartItem()).getProduct().setUnitinstock(k);*/
		//session.saveOrUpdate(object);
		
		}
		
		removeAllCartItems(cart);
		//reduction();
				
	}
	
	
	/*public void reduction()
	{
		
		if (product.getUnitinstock() < 1)
		{	
			int id=product.getProductid();
			Session session1=sessionFactory.openSession();
			
			Product product=(Product)session1.get(Product.class,id);
			session1.delete(product);
		}
		else
		{
			
		}
		
		
	}
*/
	


}
