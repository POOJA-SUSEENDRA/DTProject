
package com.spring.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.spring.model.Product;
@Repository
public class ProductDaoImpl implements ProductDao{
	@Autowired
private SessionFactory sessionFactory;
	
	
	public SessionFactory getSessionFactory() {
	return sessionFactory;
}

public void setSessionFactory(SessionFactory sessionFactory) {
	this.sessionFactory = sessionFactory;
}
	public List<Product> getAllProducts() {
		Session session=sessionFactory.openSession();
		List<Product> product=session.createQuery("from Product").list();
		System.out.println("in dao");
		
		System.out.println(product);
		
		session.close();
		return product;
	}

	public Product getProductById(int i) {
		//reading the record from the table
	  Session session=sessionFactory.openSession();
	  //select * from book where isbn=i
	  //if we call get method,Record doesnot exist it will return null
	  //if we call load, if the record doesnt exist it will throw exception
	  Product product=(Product)session.get(Product.class, i);  
	  session.close();
	  return product;
	}

	public void deleteProduct(int id){
		System.out.println("IN product daoIMPL");
		Session session=sessionFactory.openSession();
		//select * from book where isbn=?
		Product product=(Product)session.get(Product.class,id);
				
		System.out.println(product);
		
		
		//delete from book where isbn=?
		session.delete(product);
		 

		//commit the changes
		//changes to the database will become permanent
		session.flush();
		//closing the connection with the database.
		session.close();//close the session	

	}

	public void addProduct(Product product) {
		Session session=sessionFactory.openSession();
		session.save(product);
		session.close();	
}


	
	public void editProduct(Product product) {
			Session session=sessionFactory.openSession();
			//update bookapp set ....where isbn=?
			
			System.out.println("in edit product. Productdao");
			
			System.out.println("Product Details"+product.getProductid() + " "+product.getProductname()+ " "+product.getProductmanufacturer()+ " "+product.getCategory().getCategoriesid()+" "+ product.getCategory().getCategories() + " "+product.getProductdescription()+ " "+product.getUnitinstock()+ " "+product.getProductprice());
			
			
			/*Integer p=product.getProductid();
			*/
			
			
			
			session.saveOrUpdate(product);
			session.flush();
			session.close();
	}

	
	
	

}
