package com.spring.mvc;





import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.ModelAndView;

import com.spring.model.Category;
import com.spring.model.Product;
import com.spring.services.ProductService;
@Controller
public class ProductController {
	@Autowired
private ProductService productService;
/*	@Autowired
private Product product;

public Product getProduct() {
	return product;
}

public void setProduct(Product product) {
	this.product = product;
}*/

public ProductService getProductService() {
	return productService;
}

public void setProductService(ProductService productService) {
	this.productService = productService;
}
@RequestMapping("/getAllProducts")
public ModelAndView getAllProducts(){
	
	
	List<Product> products = productService.getAllProducts();
//	if(product.getUnitinstock()>0)
//	{
	return new ModelAndView("productsList","Product",products);
//	}
	/*else
	{
		return new ModelAndView("productsList","Product",product);
	}*/
	
}

@RequestMapping("/getProductById/{productid}")
public ModelAndView getProductById(@PathVariable(value="productid") int productid){
	Product p=productService.getProductById(productid);
	return new ModelAndView("productPage","productObj",p);
}


@RequestMapping("/admin/delete/{id}")
public String deleteProduct(@PathVariable(value="id") int id){
	Path path=Paths.get("C:/Users/SLT-02/workspace/prod/src/main/webapp/WEB-INF/resources/images/" + id + ".png");
	if(Files.exists(path))
	{
           try {
			Files.delete(path);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	productService.deleteProduct(id);
	//http://localhost:8080/appname/getAllBooks
	return "redirect:/getAllProducts";
}



@RequestMapping(value="/admin/product/addProduct",method=RequestMethod.GET)
public String getProductForm(Model model){
	Product product=new Product();
	Category category=new Category();
	category.setCategoriesid(1);//New Arrivals
	//set the category as 1 for the Book book
	product.setCategory(category);
	model.addAttribute("productFormObj",product);
	return "productForm";
	
}
@RequestMapping(value="/admin/product/addProduct",method=RequestMethod.POST)
public String addProduct(@Valid @ModelAttribute(value="productFormObj")  Product product,BindingResult result){
	
	System.out.println("in product controller");
	if(result.hasErrors())
		return "productForm";
	productService.addProduct(product);

	MultipartFile image=product.getProductImage();
	if(image!=null && !image.isEmpty()){
		
		
	
	Path path=Paths.get("C:/Users/SLT-02/workspace/prod/src/main/webapp/WEB-INF/resources/images/" + product.getProductid() + ".png");
	
	//	java.io.File f=new java.io.File("webapp/WEB-INF/resources/images/" + product.getProductid() + ".png"); 
		
		try {
		image.transferTo(new File(path.toString()));		
		//image.transferTo(new File(f.toString()));
	} catch (IllegalStateException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
	return "redirect:/getAllProducts";
}


@RequestMapping("/admin/product/editProduct/{id}")
public ModelAndView getEditForm(@PathVariable(value="id")  int id){
	//First read the record which has to be updated
	//select * from bookapp where isbn=?
	//Populate the form with already existing value

	System.out.println(id);
	
	System.out.println("in product controller get method edit");
	
	Product product=this.productService.getProductById(id);
	
	System.out.println(product+" Using GET METHOD");
	
	
	
	return new ModelAndView("editProductForm","editProductObj",product);
}

/*

@RequestMapping("admin/product/editProduct/${p.productid }")
public ModelAndView getProductForm(@PathVariable(value="id")  int id){
	//First read the record which has to be updated
	//select * from bookapp where isbn=?
	//Populate the form with already existing value
	Product product=this.productService.getProductById(id);
	return new ModelAndView("editProductForm","editProductObj",product);
}
*/
@RequestMapping(value="/admin/product/editProduct",method=RequestMethod.POST)
public String editProduct(@ModelAttribute(value="editProductObj") Product product)


//public String editProduct(@ModelAttribute(value="editProductObj") Product product,HttpServletRequest req)
  {
	
	
	/*int id=Integer.parseInt(req.getParameter("productid"));
	String str1=req.getParameter("productname");
	String str2=req.getParameter("productdescription");
	int price=Integer.parseInt(req.getParameter("productprice"));
	String str4=req.getParameter("productmanufacturer");
	
	int unit=Integer.parseInt(req.getParameter("unitinstock"));
	int rb=Integer.parseInt(req.getParameter("rb"));
	*/
	
	
	int value=product.getCategory().getCategoriesid();
	
	if(value == 1)
		product.getCategory().setCategories("New Arrivals");
	if(value == 2)
		product.getCategory().setCategories("General");
	
	if(value == 3)
		product.getCategory().setCategories("Special Discounts");
	
	
	
	System.out.println(product);
	
	System.out.println("in product controller post method edit");
	productService.editProduct(product);
	return "redirect:/getAllProducts";

   }

@RequestMapping("/getProductsList")
public @ResponseBody List<Product> getProductsListInJSON(){
	
	
	
	return productService.getAllProducts();
}
/*
@RequestMapping("/productsListAnguler")
public String getProducts(){
	return "productsListAnguler";
}*/
@RequestMapping("/productsList")
public String getProducts(){
	return "productsList";
}

/*
@Bean
public MultipartResolver multipartResolver(){
	CommonsMultipartResolver multipartResolver=new CommonsMultipartResolver();
	multipartResolver.setMaxUploadSize(10240000);
	return multipartResolver;
}*/








}
