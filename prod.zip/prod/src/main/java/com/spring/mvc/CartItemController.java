package com.spring.mvc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import com.spring.dao.CartItemDao;
import com.spring.dao.CartItemDaoImpl;
import com.spring.model.Cart;
import com.spring.model.CartItem;
import com.spring.model.Customer;
import com.spring.model.Product;
import com.spring.services.CartItemService;
import com.spring.services.CartService;
import com.spring.services.CustomerServices;
import com.spring.services.ProductService;

@Controller
public class CartItemController {
	
//it needs CartItemService
@Autowired	
private CustomerServices customerServices;
@Autowired
private ProductService productServices;
@Autowired
private CartItemService cartItemService;
@Autowired
private CartService cartService;
/*@Autowired
private Product product;
*/
@Autowired
private CartItemDaoImpl cartItemDaoImpl ;



public CartItemDaoImpl getCartItemDaoImpl() {
	return cartItemDaoImpl;
}


public void setCartItemDaoImpl(CartItemDaoImpl cartItemDaoImpl) {
	this.cartItemDaoImpl = cartItemDaoImpl;
}


public CartService getCartService() {
	return cartService;
}


public void setCartService(CartService cartService) {
	this.cartService = cartService;
}


public CartItemService getCartItemService() {
	return cartItemService;
}


public void setCartItemService(CartItemService cartItemService) {
	this.cartItemService = cartItemService;
}


public CustomerServices getCustomerServices() {
	return customerServices;
}


public void setCustomerServices(CustomerServices customerServices) {
	this.customerServices = customerServices;
}


public ProductService getProductServices() {
	return productServices;
}


public void setProductServices(ProductService productServices) {
	this.productServices = productServices;
}


@RequestMapping("/cart/add/{productid}")
@ResponseStatus(value=HttpStatus.NO_CONTENT)
public void addCartItem(@PathVariable(value="productid") int productid){
	//Is to get the username of the customer
	//User object contains details about the user -username , password, activeuser or not
	User user=(User)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
	String username=user.getUsername();
	Customer customer=customerServices.getCustomerByUsername(username);
	System.out.println("Customer is " + customer.getCustomerEmail() );
	Cart cart=customer.getCart();
	
	List<CartItem> cartItems=cart.getCartItem();
	Product product=productServices.getProductById(productid);
	for(int i=0;i<cartItems.size();i++){
		CartItem cartItem=cartItems.get(i);
		if(product.getProductid()==cartItem.getProduct().getProductid()){
			cartItem.setQuantity(cartItem.getQuantity() + 1);
			cartItem.setTotalPrice(cartItem.getQuantity() * cartItem.getProduct().getProductprice());
			cartItemService.addCartItem(cartItem);
			return;
		}
	}
	CartItem cartItem=new CartItem();
	cartItem.setQuantity(1);
	cartItem.setProduct(product);
	cartItem.setTotalPrice(product.getProductprice() * 1);
	cartItem.setCart(cart);
	cartItemService.addCartItem(cartItem);
	
	
}


@RequestMapping("/cart/removecartitem/{cartItemId}")
@ResponseStatus(value=HttpStatus.NO_CONTENT)
public void removeCartItem(
	@PathVariable(value="cartItemId") int cartItemId){
	cartItemService.removeCartItem(cartItemId);
}

@RequestMapping("/cart/removeAllItems/{cartId}")
@ResponseStatus(value=HttpStatus.NO_CONTENT)
public void removeAllCartItems(@PathVariable(value="cartId") int cartId){
	System.out.println(cartId +"in cartitem controller");
	
	Cart cart=cartService.getCartByCartId(cartId);
	System.out.println(cart);
	
	cartItemService.removeAllCartItems(cart);
	
}


		
		
}		