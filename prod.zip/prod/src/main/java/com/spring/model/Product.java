package com.spring.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import org.hibernate.annotations.Check;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.web.multipart.MultipartFile;

@Entity
@Table(name="product")
public class Product implements Serializable {
	@Id
	@Column(name="productid")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int productid;
	
	
	@NotEmpty(message="name is mandatory")
	private String productname;

/*private String productcategory;*/

@NotEmpty(message="manufacturer is mandatory")
private String productmanufacturer;

	
@Min(value=100,message="Minimum value should be greater than 100")
private double productprice;

private String productdescription;
//@Check(constraints = "available_count >= 0")
private int unitinstock;

@ManyToOne(cascade=CascadeType.ALL,fetch=FetchType.EAGER)
@JoinColumn(name="categories")//category is the name of the foreign key column in bookApp table
private Category category;



/*private int categoryid;
public int getCategoryid() {
	return categoryid;
}
public void setCategoryid(int categoryid) {
	this.categoryid = categoryid;
}
*/



@Transient
private MultipartFile productImage;

public MultipartFile getProductImage() {
	return productImage;
}
public void setProductImage(MultipartFile productImage) {
	this.productImage = productImage;
}

public Category getCategory() {
	return category;
}
public void setCategory(Category category) {
		this.category = category;
}
public int getUnitinstock() {
	return unitinstock;
}
public void setUnitinstock(int unitinstock) {
	
	if (unitinstock < 0) 
	{	
		 this.unitinstock = 0;
	}
	else{
		this.unitinstock = unitinstock;
		
	}
}
public String getProductdescription() {
	return productdescription;
}
public void setProductdescription(String productdescription) {
	this.productdescription = productdescription;
}
public double getProductprice() {
	return productprice;
}
public void setProductprice(double productprice) {
	this.productprice = productprice;
}
public String getProductname() {
	return productname;
}
public void setProductname(String productname) {
	this.productname = productname;
}

public int getProductid() {
	return productid;
}
public void setProductid(int productid) {
	this.productid = productid;
}
/*public String getProductcategory() {
	return productcategory;
}
public void setProductcategory(String productcategory) {
	this.productcategory = productcategory;
}
*/
public String getProductmanufacturer() {
	return productmanufacturer;
}
public void setProductmanufacturer(String productmanufacturer) {
	this.productmanufacturer = productmanufacturer;
}




public String toString()
{
	
	return new StringBuffer().append(getProductid() + getCategory().getCategories()).toString();
}

}


