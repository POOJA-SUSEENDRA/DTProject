package com.spring.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/*import com.fasterxml.jackson.annotation.JsonIgnore;*/
@Entity
@Table(name="categories")
public class Category implements Serializable{ // Category has list of Books
@Id
private int categoriesid;
@Column(name="categories")
private String categories;
@OneToMany(mappedBy="category")


/*@JsonIgnore
List<Product> products;
*/
public int getCategoriesid() {
	return categoriesid;
}
public void setCategoriesid(int categoriesid) {
	this.categoriesid =categoriesid;
}

public String getCategories() {
	return categories;
}
public void setCategories(String categories) {
	this.categories = categories;
}
/*public void setProducts(List<Product> products) {
	this.products = products;
}
public List<Product> getProducts() {
	return products;
}*/
/*public void setBooks(List<Product> products) {
	this.products = products;
}
*/


public String toString()
{
	
	return new StringBuffer().append(getCategoriesid() + getCategories()).toString();
}


}
