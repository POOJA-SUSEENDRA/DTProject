package com.spring.validator;

public class CommonModules {

	
	/*private static String malaciousWords[]={"Drop","Delete","Truncate","Update","select","Insert"};*/
	private  static char  malaciousCharacters[]={'/','!','@','#','$','%','^','&','*','(',')','`','~',',','|',';',':','"','<','>','_','-','+','=','{','}','[',']'};
	

	public static boolean checkMaliaciousChars(String value)
	{
		boolean isFound=false;
		char array[]=value.toCharArray();
		
		for(char a : malaciousCharacters)
		{
			
			for( char c : array)
			{
				
				
				if(a == c)
				{
					isFound=true;
					break;
				}
				
			}
			
			
			
		}
		
		return isFound;
	}
	
	public static boolean checkNumeric(String value)
	{
		
		boolean isFound=false;
		char array[]=value.toCharArray();
		
		for( char c: array)
		{
		if(Character.isDigit(c))
		{
			isFound=true;
			break;
	
			
			
		}
		
			
		}
		return isFound;
		
	}
	
	
	
	
	
	
}
